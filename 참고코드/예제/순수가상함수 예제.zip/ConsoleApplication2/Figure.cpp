#include "Figure.h"



Figure::Figure()
{
}

Figure::~Figure()
{
}
